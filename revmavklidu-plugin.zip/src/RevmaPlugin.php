<?php
namespace Revma;

use Revma\Survey;

class RevmaPlugin
{
    private $_survey;

    public function __construct()
    {
        add_action('init', [$this, 'init']);
    }

    public function init()
    {
        $this->_survey = new Survey();
        $this->_survey->init();
    }
}
